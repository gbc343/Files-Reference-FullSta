import React, { Component } from 'react';  
//import ReactDom from 'react-dom';
//import{View, Button, TextInput} from 'react-native'
import './App.css';
//import {useFormik} from 'formik';

class App extends Component {
  constructor (props) {
    super(props);
    this.state = {
      fullN:'',
      email:'',
      address:'',
      province:'',
      postalCode:'',
      city:'',
      inputvalue:'',
      inputvalue2:'',
      inputvalue3:'',
      inputvalue4:'',
      inputvalue5:'',
      inputvalue6:''

    }
    this.handleSubmit = this.handleSubmit.bind(this);
    this.handleChange = this.handleChange.bind(this);
}


handleChange(event){
  /*this.setState({fullName: event.target.value,
  email:event.target.value, address:event.target.value});
  */
 this.setState({[event.target.name]: event.target.value})
 
}

handleSubmit (event) {
  this.setState({
  inputvalue:"Email :" + this.state.email,
  inputvalue2:"Full Name: " + this.state.fullN,
  inputvalue3: "Address: " + this.state.address,
  inputvalue4:"City: " + this.state.city,
  inputvalue5:'Province: ' + this.state.province,
  inputvalue6:'Postal Code: ' + this.state.postalCode

  })
  event.preventDefault();
  }

render(){
  return (
    
    <div className="App">
      <h1>Data Entry Form</h1>
     <form onSubmit={this.handleSubmit.bind(this)}>

      <label for="email">Email</label><br/>
      <input type="text" id="email" name="email" value={this.state.email} onChange={this.handleChange}></input> <br/>
      <label for="address">Address</label><br/>
      <input type="text" id="address" name="address"  value={this.state.address}  onChange={this.handleChange}></input> <br/>
      <label for="fullN">Full Name</label><br/>
      <input type="text" id="fName" name="fullN"  value={this.state.fullN}  onChange={this.handleChange}></input> <br/>

      <select name="province" id="province" placeholder="options" value={this.state.province} onChange={this.handleChange}>
        <option value="alberta">alberta</option>
        <option value="british columbia">british columbia</option>
        <option value="manitoba">manitoba</option>
        <option value="new brunswick">news brunswick</option>
      </select>
      <label for="city">City</label><br/>
      <input type="text" id="city" name="city"  value={this.state.city}  onChange={this.handleChange}></input> <br/>
      <label for="post">Postal Code</label><br/>
      <input type="text" id="post" name="postalCode"  value={this.state.postalCode}  onChange={this.handleChange}></input> <br/>
      <input type="submit" value="Submit"/>
     </form>

     <label style ={{color:'red'}}>{this.state.inputvalue}</label><br/>
     <label style ={{color:'red'}}>{this.state.inputvalue2}</label><br/>
     <label style ={{color:'red'}}>{this.state.inputvalue3}</label><br/>
     <label style ={{color:'red'}}>{this.state.inputvalue4}</label><br/>
     <label style ={{color:'red'}}>{this.state.inputvalue5}</label><br/>
     <label style ={{color:'red'}}>{this.state.inputvalue6}</label><br/>
    </div>
    
  );

}
}


export default App;
