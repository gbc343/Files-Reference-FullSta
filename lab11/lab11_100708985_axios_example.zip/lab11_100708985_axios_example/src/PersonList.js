import React, {Component} from 'react'
import axios from 'axios'
//import fetch from 'react-native-fetch'


export default class PersonList extends Component{
  //Define state default values
  state = {
    persons: []
}

 //Component Lifecycle Callback
async componentDidMount() {
    
    axios.get(`https://randomuser.me/api/?results=10`)
    .then(res => {
        console.log(res.data);
        const persons = res.data.results;
        this.setState({ persons });
    })

    //const url = "https://randomuser.me/api/?results=10";
    //const res = await fetch(url);
    //const data = await res.json();
   // console.log(data);
    

}

//Time Zone Description: {person.timezone.description}


    render(){
        return(
    <div>
            <h1 style={{width:"100%", backgroundColor: "green", textAlign:"center"}}>User List</h1>

    <table style={{width:"100%", backgroundColor: "lightgreen"}}>
    { this.state.persons.map(person =>
    <ul style={{backgroundColor:"grey", borderstyle:"solid", width:"100%"}}>
        <tr style={{width:"100%"}}>
            <th style={{borderStyle:"solid" , backgroundColor:"lightgrey" ,width:"100%"}}>{person.name.title} {person.name.first} {person.name.last} - {person.login.uuid}</th>
        </tr>
        <tr>
        </tr>
        <td style={{display:"inline-block", alignContent:"left"}}><img style={{display:"inline-block", alignContent:"left", verticalAlign:"left", borderRadius:"50%"}} src={person.picture.large} alt="Girl in a jacket" width="150" height="150"/></td>


        
        <td style={{ display:"inline-block"}}>
            <tr>User Name: </tr>
            <tr>Gender: </tr>
            <tr>Address: </tr>
            <tr>Email: </tr>
            <tr>Birth Date and Age:</tr>
            <tr>Register Date: </tr>
            <tr>Phone#</tr>
            <tr>Cell#: </tr>
            
            </td>  
            <td style={{ display:"inline-block"}} >
                <tr> {person.login.username}</tr>
                <tr>{person.gender}</tr>
                <tr>{person.location.street.number} {person.location.street.name}, {person.location.city}, {person.location.state}, {person.location.country}</tr>
                <tr>{person.email}</tr>
                <tr>{person.dob.date}, {person.dob.age}</tr>
                <tr>{person.registered.date}</tr>
                <tr>{person.phone}</tr>
                <tr>{person.cell}</tr>

            </td>  


        </ul>
        )}
</table>
</div>
        )
    }
}

