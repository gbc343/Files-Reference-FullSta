import logo from './logo.svg';
import './App.css';
import HomePage from './HomePage'
import { UserProvider } from './UserContext'
import ContactUsPage from './ContactUsPage'

function App() {
  const user = { name: 'Gordon Wells', email:'p@p.com', loggedIn: true }

  return (
    <UserProvider value={user}>
      <HomePage />
      <ContactUsPage/>
    </UserProvider>
  )
}

export default App;
