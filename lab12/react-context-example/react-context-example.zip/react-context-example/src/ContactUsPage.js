import React,{Component} from 'react'
import UserConsumer from './UserContext'


export default class ContactUsPage extends Component{
    render() {
        return (
            <div>
                <UserConsumer>
                    {(props)=>{
                        return <h5>{props.email}</h5>
                    }}
                </UserConsumer>
            </div>
        )
    }
}