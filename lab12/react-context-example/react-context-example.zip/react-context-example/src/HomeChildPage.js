import React, { Component } from 'react'
import UserContext from './UserContext'



export default class HomeChildPage extends Component {

    static contextType = UserContext
    user =''

    componentDidMount(){
        const user = this.context
        console.log(user)
    }

    render() {
        return (
            <div>
                <h2 style={{color:'red'}}>I am inside Home Child</h2>
                <h3>{this.context.name}</h3>
            </div>
        )
    }
}

