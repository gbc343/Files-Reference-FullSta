import React, { Component } from 'react'
import HomeChildPage from './HomeChildPage'
import UserConsumer from './UserContext'
class HomePage extends Component {
  static contextType = UserConsumer

  render() {
    return(
        <UserConsumer>
            {(props) => {
                return (
                <>
                    <h1>{props.name}</h1>
                    <HomeChildPage/>
                </>
                )
                
            }}
        </UserConsumer>
    )
  }
}

export default HomePage