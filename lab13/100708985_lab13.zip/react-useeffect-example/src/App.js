import './App.css';
import CounterWithNameAndSideEffect from "./CounterWithNameAndSideEffect"
import EffectDemo from './EffectDemo'
import CountryList from './CountryList'
function App() {
  return (
    <>
      <h1>Lab Exercise Week 13 - 100708985</h1>
      <CounterWithNameAndSideEffect />
      <EffectDemo/>
      <CountryList/>
    </>
  )
}

export default App;
