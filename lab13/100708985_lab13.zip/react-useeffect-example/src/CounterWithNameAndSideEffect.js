import React, { useEffect, useState } from 'react'

//const { useEffect, useState } = React

//Create Component
const CounterWithNameAndSideEffect = () => {
  const [count, setCount] = useState(0)
  //Update you name here
  const [name, setName] = useState('Flavio')
  //Add your student id field as userState and display

  useEffect(() => {
    console.log(`Hi ${name} you clicked ${count} times`)
    return () => {
        console.log(`Unmounted`)
      }
  },[count])
  //Update line# 15 to call useEffect when only name got changed

  return (
    <div>
      <p>
        Hi {name} you clicked {count} times
      </p>
      <button onClick={() => setCount(count + 1)}>Click me</button>
      <button onClick={() => setName(name === 'Flavio' ? 'Gordon Wells' : 'Flavio')}>
        Change name
      </button>
    </div>
  )
}

export default CounterWithNameAndSideEffect;
