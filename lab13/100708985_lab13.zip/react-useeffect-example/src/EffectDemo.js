import React, {useState, useEffect} from 'react';

 const EffectDemo = () => {
    //State
    const [fullName, setFullName] = useState({name: 'name', familyName: 'family'});
    const [title,setTitle] = useState('useEffect() in Hooks');
    
    //Add useEffect here to update values
    //setFullName({name:'Pritesh',familyName: 'Patel'});

    //never set the state inside useEffect as it will rerender the components
    useEffect(() => {
            //setFullName({name:'Gordon',familyName: 'wells'});   
    })

    return(
        <div>
            <h1>Title: {title}</h1>
            <h3>Name: {fullName.name}</h3>
            <h3>Family Name: {fullName.familyName}</h3>
        </div>
    );
};

export default EffectDemo;