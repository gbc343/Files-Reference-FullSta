import logo from './logo.svg';
import './App.css';
import React from 'react';


class App extends React.Component {
  constructor(props) {
    super(props);
      this.state = {
 
        heading: "Welcome to Fullstack Development-1",
        quote: "React JS Programming Week09 Lab excercise",
        studentId: "100708985",
        name: "Gordon Wells",
        school: "George Brown College, Toronto"
  
      }
    }
        render() {
        return (
        <div className="App"> 
            <img src={logo} className="App-logo" alt="logo"/>
            <>
          <h1>{this.state.heading}</h1>
          <h2>{this.state.quote}</h2>
          <h3>{this.state.studentId}</h3>
          <h3>{this.state.name}</h3>
          <h4>{this.state.school}</h4>
            </>
          
        </div>

      );
   }
}
export default App;
