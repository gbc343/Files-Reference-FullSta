
function Student() {
  return (
    <>
    <h1>Student Component</h1>
   
    
    </>
  );
}

export default Student;
